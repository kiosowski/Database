﻿namespace SoftJail.Data.Models
{
    public enum Weapon
    {
        Knife,
        FlashPulse,
        ChainRifle,
        Pistol,
        Sniper
    }
}
﻿namespace SoftJail.Data.Models
{
    public enum Position
    {
        Overseer,
        Guard,
        Watcher,
        Labour
    }
}
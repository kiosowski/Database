﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    internal class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-OSBRO1S\SQLEXPRESS;Database=Hospital;
            Integrated Security=True";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-OSBRO1S\SQLEXPRESS;Database=StudentSystem;
                                     Integrated Security=True";
    }
}

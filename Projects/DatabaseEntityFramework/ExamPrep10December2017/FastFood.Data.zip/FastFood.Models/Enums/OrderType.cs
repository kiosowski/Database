﻿namespace FastFood.Models
{
    public enum OrderType
    {
        ForHere,
        ToGo
    }
}
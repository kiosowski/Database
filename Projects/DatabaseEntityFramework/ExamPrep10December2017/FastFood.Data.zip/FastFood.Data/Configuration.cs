namespace FastFood.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=DESKTOP-OSBRO1S\SQLEXPRESS;Database=FastFood;Trusted_Connection=True";
	}
}
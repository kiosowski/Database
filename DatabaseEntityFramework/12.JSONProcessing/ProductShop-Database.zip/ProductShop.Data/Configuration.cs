﻿namespace ProductShop.Data
{
    public class Configuration
    {
        public static string ConnectionString => @"Server=.; Database=ProductShop;Integrated Security=True";
    }
}
